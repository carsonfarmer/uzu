# North Mini Code on Apple M4 Pro

Start with NORTH_RESULTS.md and experiments/north/share/north-m4-pro-results.png.
Reproduction commands: experiments/north/quantized/README.md.
Cohere mechanism mapping: experiments/north/correctness/COHERE_REFERENCE.md.
Tweet drafts: experiments/north/share/SHARE.md.

This bundle contains corrected code and raw evidence. It contains no model
weights or raw system traces. The preparation script downloads and verifies
the pinned public model and runtime source separately. The experiment was
tested on a 48 GB M4 Pro with macOS 27.0 and MLX 0.32.2. All model and GPU runs
require a suitable Apple device; only this specific device has been tested.

The source snapshots under correctness/results identify the exact versions
used for each recorded gate and benchmark. Older failed-prototype evidence
is retained for diagnosis and is not pooled into the final estimates.
