# A tweetable result, with the limits attached

The useful story: we took Cohere's scheduling ideas from a controlled Metal
branch experiment into real North Mini Code decoding on an M4 Pro. A positive
branch timing did not turn into a faster or equivalent decoder. That distinction
is the result; this is not an announcement of an Apple megakernel speedup.

Attach `north-m4-pro-results.png`. It has the relevant scopes, units and caveats
inside the image. The packet is ready locally; code and raw runs do not yet
have a public URL. Nothing has been posted or sent.

## Single-post draft

> Cohere's megakernel post inspired an M4 Pro experiment with North Mini Code 4-bit. Scheduling cut GPU time 6-10% in a real-data BF16 branch. Full-model integration was slower than MLX and changed tokens. Fewer launches weren't enough. Repro harness + raw runs ready.

## Optional follow-ups

> The full-model test replaced the branch in all 48 MoE layers. Original MLX: 49-54 tok/s across three prompts. Custom Metal: 38-43. Batch 1, 256-token cap, warmup + 3 runs. A compiled-native control kept the original outputs. The custom continuations differed.

> A numerical trap: the same formula isn't the same BF16 computation. Matching MLX's intermediate input-sum and sigmoid rounding made one captured branch exact and brought another to 0.0009% relative L2 error. That still did not preserve full-model logits.

> All schedules matched their phased controls bitwise. Across 192 identical-input decode checks, the custom path agreed on 190 greedy choices, then diverged during longer generation. Branch checks and short token agreement weren't enough to promote it.

> Apple-specific observation: a 20-worker persistent pool was much slower on this 20-core M4 Pro. More workgroups helped. The result covers local dependency chains and branch placement; cross-threadgroup waits and weight prefetch are still untested.

## What the chart measures

1. Materialized BF16 branch: static 128 workers versus identical phased math,
   GPU time, three runs each at layers 1 and 7. About 6–10% lower GPU time.
2. Packed W4 branch: the selected 64-feature/128-worker mixed schedule versus
   compiled-native MLX, host wall time. Median paired changes are 16–21% slower
   across six runs. The axes intentionally have different units and controls.
3. Full-model free generation: medians and min/max of three requests per cell.
   The custom path is slower and generates different continuations. These are
   not equivalent-output speedup measurements.

Hardware: M4 Pro, 20 GPU cores, 48 GB. OS: macOS 27.0 beta build 26A5425a.
Runtime: MLX 0.32.2 and pinned mlx-vlm text-model source. Model: the community
MLX affine 4-bit/group64 conversion, not Cohere's BF16 or NVFP4 checkpoint.
All measurements come from one desktop Mac, with timing drift and unlocked
GPU clocks. No broad Apple-device or production-quality claim is warranted.

The complete explanation is `NORTH_RESULTS.md` at the packet root. Exact input
hashes, dependency versions, numerical checks, raw timing, token IDs and
reproduction instructions accompany the source. The baseline also produced
complete Python/Rust code that passed the recorded checks; that does not
establish the custom route's coding quality.
